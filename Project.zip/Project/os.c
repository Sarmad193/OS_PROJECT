#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <sys/time.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <semaphore.h>

pid_t p[16];
sem_t lock;
int ram = 0;
int memReq[16];
int hdd = 0;
int userMode = 1;  // User mode: 1, Kernel mode: 0

struct process {
    int p1;
};

struct ReadyQueue {
    struct process queue[11];
    int front;
    int rear;
};
void switchToUserMode() {
    userMode = 1;
}
void switchToKernelMode() {
    userMode = 0;
}

struct ReadyQueue RQ = { .front = -1, .rear = -1 };


int isFull(struct ReadyQueue* q) {
    return (q->rear + 1) % 11 == q->front;
}

int isEmpty(struct ReadyQueue* q) {
    return q->front == -1 && q->rear == -1;
}

void enqueue(struct ReadyQueue* q, int pro) {
    if (isFull(q)) {
        printf("Error: Queue is full\n");
        return;
    }
    if (isEmpty(q)) {
        q->front = 0;
        q->rear = 0;
    }
    else {
        q->rear = (q->rear + 1) % 11;
    }
    q->queue[q->rear].p1 = pro;
}

int dequeue(struct ReadyQueue* q) {
    if (isEmpty(q)) {
        return -1;
    }
    int pid = q->queue[q->front].p1;
    if (q->front == q->rear) {
        q->front = -1;
        q->rear = -1;
    }
    else {
        q->front = (q->front + 1) % 11;
    }
    return pid;
}
void loadingBar()
{
	int i = 0;
        for (i = 0; i < 20; i++){
           printf("##");
        }
        printf("\n");
        sleep(3);
        fflush(stdout);
}

void AssResources() {
    if (!userMode) {
        printf("Error: Not allowed in kernal mode.\n");
        return;
    }
    int rm, hardd;
    printf("Enter the Memory(GB): ");
    scanf("%d", &rm);
    printf("Enter the Space(GB):");
    scanf("%d", &hardd);
    ram = rm*1024;
    hdd = hardd*1024;
}

void clearScreen() {
    system("clear");
}


void Boot_loader() {
    clearScreen();
    char uname[50] = { 0 }, pass[50] = { 0 }, temU[50] = { 0 }, temP[50] = { 0 };
    int flag = 1;
    strcpy(uname, "Sarmad");
    strcpy(temU, "Sarmad");
    strcpy(pass, "123");
    printf("Allocating Resources\n");
    AssResources();
    clearScreen();
    printf("Starting the Sunshine OS\n");
    loadingBar();
    while (flag) {
        printf("Enter Login information:\n");
        printf("User name: Sarmad\n");
        printf("Enter password: ");
        scanf("%s", temP);
        if ((strcmp(temU, uname) == 0) && (strcmp(temP, pass) == 0)) {
            printf("Login Successful\n");
            flag = 0;
        }
        else {
            printf("Incorrect Username\n");
        }
    }
}

void* runCalculator(void* arg) {
    int arg_value = *((int*)arg);
    sem_wait(&lock);
    if (arg_value) {
        p[0] = fork();
        if (p[0] == 0) {
            char* argv[] = { "gnome-terminal", "--disable-factory", "--", "./calc", NULL };
            if (execvp(argv[0], argv) == -1) {
                perror("Error in execvp");
            }
        }
        else {
            int status;
            waitpid(p[0], &status, 0);
            ram += memReq[0];
            pthread_exit(NULL);
        }
    }
    else {
        memReq[0] = 20;
        enqueue(&RQ, 0);
    }
    pthread_exit(NULL);
}

void* runClock(void* arg) {
    int arg_value = *((int*)arg);
    sem_wait(&lock);
    if (arg_value) {
        p[1] = fork();
        if (p[1] == 0) {
            char* argv[] = { "gnome-terminal", "--disable-factory", "--", "./clock.sh", NULL };
            if (execvp(argv[0], argv) == -1) {
                perror("Error in execvp");
            }
        }
        else {
            int status;
            waitpid(p[1], &status, 0);
            ram += memReq[1];
            pthread_exit(NULL);
        }
    }
    else {
        memReq[1] = 15;
        enqueue(&RQ, 1);
    }
    pthread_exit(NULL);
}

void* runVideo(void* arg) {
    int arg_value = *((int*)arg);
    sem_wait(&lock);
    if (arg_value) {
        p[2] = fork();
        if (p[2] == 0) {
            char* argv[] = { "gnome-terminal", "--disable-factory", "--", "./mediaplayer.sh", NULL };
            if (execvp(argv[0], argv) == -1) {
                perror("Error in execvp");
            }
        }
        else {
            int status;
            waitpid(p[2], &status, 0);
            ram += memReq[2];
            pthread_exit(NULL);
        }
    }
    else {
        memReq[2] = 100;
        enqueue(&RQ, 2);
    }
    pthread_exit(NULL);
}

void* runMines(void* arg) {
    int arg_value = *((int*)arg);
    sem_wait(&lock);
    if (arg_value) {
        p[3] = fork();
        if (p[3] == 0) {
            char* argv[] = { "gnome-terminal", "--disable-factory", "--", "./mines.sh", NULL };
            if (execvp(argv[0], argv) == -1) {
                perror("Error in execvp");
            }
        }
        else {
            int status;
            waitpid(p[3], &status, 0);
            ram += memReq[3];
            pthread_exit(NULL);
        }
    }
    else {
        memReq[3] = 150;
        enqueue(&RQ, 3);
    }
    pthread_exit(NULL);
}

void* runFileExplorer(void* arg) {
    int arg_value = *((int*)arg);
    sem_wait(&lock);
    if (arg_value) {
        p[5] = fork();
        if (p[5] == 0) {
            char* argv[] = { "gnome-terminal", "--disable-factory", "--", "./fileExp", NULL };
            if (execvp(argv[0], argv) == -1) {
                perror("Error in execvp");
            }
        }
        else {
            int status;
            waitpid(p[5], &status, 0);
            ram += memReq[5];
            pthread_exit(NULL);
        }
    }
    else {
        memReq[5] = 100;
        enqueue(&RQ, 5);
    }
    pthread_exit(NULL);
}

void* runBrowser(void* arg) {
    int arg_value = *((int*)arg);
    sem_wait(&lock);
    if (arg_value) {
        p[4] = fork();
        if (p[4] == 0) {
            char* argv[] = { "gnome-terminal", "--disable-factory", "--", "./browser.sh", NULL };
            if (execvp(argv[0], argv) == -1) {
                perror("Error in execvp");
            }
        }
        else {
            int status;
            waitpid(p[4], &status, 0);
            ram += memReq[4];
            pthread_exit(NULL);
        }
    }
    else {
        memReq[4] = 200;
        enqueue(&RQ, 4);
    }
    pthread_exit(NULL);
}

void* runCal(void* arg) {
    int arg_value = *((int*)arg);
    sem_wait(&lock);
    if (arg_value) {
        p[6] = fork();
        if (p[6] == 0) {
            char* argv[] = { "gnome-terminal", "--disable-factory", "--", "./calen.sh", NULL };
            if (execvp(argv[0], argv) == -1) {
                perror("Error in execvp");
            }
        }
        else {
            int status;
            waitpid(p[6], &status, 0);
            ram += memReq[6];
            pthread_exit(NULL);
        }
    }
    else {
        memReq[6] = 10;
        enqueue(&RQ, 6);
    }
    pthread_exit(NULL);
}

void* runTM(void* arg) {
    int arg_value = *((int*)arg);
    sem_wait(&lock);
    if (arg_value) {
        p[7] = fork();
        if (p[7] == 0) {
            char* argv[] = { "gnome-terminal", "--disable-factory", "--", "./taskM.sh", NULL };
            if (execvp(argv[0], argv) == -1) {
                perror("Error in execvp");
            }
        }
        else {
            int status;
            waitpid(p[7], &status, 0);
            ram += memReq[7];
            pthread_exit(NULL);
        }
    }
    else {
        memReq[7] = 50;
        enqueue(&RQ, 7);
    }
    pthread_exit(NULL);
}

void* runNote(void* arg) {
    int arg_value = *((int*)arg);
    sem_wait(&lock);
    if (arg_value) {
        p[8] = fork();
        if (p[8] == 0) {
            char* argv[] = { "gnome-terminal", "--disable-factory", "--", "./notepad.sh", NULL };
            if (execvp(argv[0], argv) == -1) {
                perror("Error in execvp");
            }
        }
        else {
            int status;
            waitpid(p[8], &status, 0);
            ram += memReq[8];
            pthread_exit(NULL);
        }
    }
    else {
        memReq[8] = 60;
        enqueue(&RQ, 8);
    }
    pthread_exit(NULL);
}

void* runGames(void* arg) {
    int arg_value = *((int*)arg);
    sem_wait(&lock);
    if (arg_value) {
        p[9] = fork();
        if (p[9] == 0) {
            char* argv[] = { "gnome-terminal", "--disable-factory", "--", "./mahjongg.sh", NULL };
            if (execvp(argv[0], argv) == -1) {
                perror("Error in execvp");
            }
        }
        else {
            int status;
            waitpid(p[9], &status, 0);
            ram += memReq[9];
            pthread_exit(NULL);
        }
    }
    else {
        memReq[9] = 300;
        enqueue(&RQ, 9);
    }
    pthread_exit(NULL);
}
void* runRockPaper(void* arg) {
    int arg_value = *((int*)arg);
    sem_wait(&lock);
    if (arg_value) {
        p[10] = fork();
        if (p[10] == 0) {
            char* argv[] = { "gnome-terminal", "--disable-factory", "--", "./rock", NULL };
            if (execvp(argv[0], argv) == -1) {
                perror("Error in execvp");
            }
        }
        else {
            int status;
            waitpid(p[10], &status, 0);
            ram += memReq[10];
            pthread_exit(NULL);
        }
    }
    else {
        memReq[10] = 200;
        enqueue(&RQ, 10);
    }
    pthread_exit(NULL);
}

void* terminateAll(void* arg) {
    sem_wait(&lock);
    int status;
    for (int i = 0; i < 7; i++) {
        pid_t pid = getpid();
        if (pid != p[i] && kill(p[i], SIGKILL) == -1) {
            perror("Error in kill");
        }
        else if (pid != p[i]) {
            waitpid(p[i], &status, WNOHANG);
        }
    }
    pthread_exit(NULL);
}

void* QueueHandeler(void* arg) {
    while (1) {
        int n = dequeue(&RQ), m = 1, o = 0;
        pthread_t threads[16];
        switch (n) {
        case 0:
            if (ram >= memReq[0]) {
                ram -= memReq[0];
                pthread_create(&threads[0], NULL, runCalculator, &m);
            }
            else {
                pthread_create(&threads[0], NULL, runCalculator, &o);
            }
            sem_post(&lock);
            break;
        case 1:
            if (ram >= memReq[1]) {
                ram -= memReq[1];
                pthread_create(&threads[1], NULL, runClock, &m);
            }
            else {
                pthread_create(&threads[1], NULL, runClock, &o);
            }
            sem_post(&lock);
            break;
        case 2:
            if (ram >= memReq[2]) {
                ram -= memReq[2];
                pthread_create(&threads[2], NULL, runVideo, &m);
            }
            else {
                pthread_create(&threads[2], NULL, runVideo, &o);
            }
            sem_post(&lock);
            break;
        case 3:
            if (ram >= memReq[3]) {
                ram -= memReq[3];
                pthread_create(&threads[3], NULL, runMines, &m);
            }
            else {
                pthread_create(&threads[3], NULL, runMines, &o);
            }
            sem_post(&lock);
            break;
        case 4:
            if (ram >= memReq[4]) {
                ram -= memReq[4];
                pthread_create(&threads[4], NULL, runBrowser, &m);
            }
            else {
                pthread_create(&threads[4], NULL, runBrowser, &o);
            }
            sem_post(&lock);
            break;
        case 5:
            if (ram >= memReq[5]) {
                ram -= memReq[5];
                pthread_create(&threads[5], NULL, runFileExplorer, &m);
            }
            else {
                pthread_create(&threads[5], NULL, runFileExplorer, &o);
            }
            sem_post(&lock);
            break;
        case 6:
            if (ram >= memReq[6]) {
                ram -= memReq[6];
                pthread_create(&threads[6], NULL, runCal, &m);
            }
            else {
                pthread_create(&threads[6], NULL, runCal, &o);
            }
            sem_post(&lock);
            break;
        case 7:
            if (ram >= memReq[7]) {
                ram -= memReq[7];
                pthread_create(&threads[7], NULL, runTM, &m);
            }
            else {
                pthread_create(&threads[7], NULL, runTM, &o);
            }
            sem_post(&lock);
            break;
        case 8:
            if (ram >= memReq[8]) {
                ram -= memReq[8];
                pthread_create(&threads[8], NULL, runNote, &m);
            }
            else {
                pthread_create(&threads[8], NULL, runNote, &o);
            }
            sem_post(&lock);
            break;
        case 9:
            if (ram >= memReq[9]) {
                ram -= memReq[9];
                pthread_create(&threads[9], NULL, runGames, &m);
            }
            else {
                pthread_create(&threads[9], NULL, runGames, &o);
            }
            sem_post(&lock);
            break;
        case 10:
            if (ram >= memReq[10]) {
                ram -= memReq[10];
                pthread_create(&threads[10], NULL, runRockPaper, &m);
            }
            else {
                pthread_create(&threads[10], NULL, runRockPaper, &o);
            }
            sem_post(&lock);
            break;
        default:
            break;
        }
        sleep(0.5);
    }
    pthread_exit(NULL);
}
void printRunningTasks() {
    printf("Running Tasks:\n");
    for (int i = 0; i < 16; i++) {
        if (p[i] > 0) {
            printf("Task %d is running\n", i+1);
        }
    }
}
void printKernelMenu() {
    int choice;
    clearScreen();
    do {
        
        printf("Kernel Mode Menu\n");
        printf("1. Print Running Tasks\n");
        printf("2. Exit\n");

        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printRunningTasks();
                printf("\n\n\n");
                break;
            case 2:
                switchToUserMode();
                printf("Exiting Kernel Mode\n");
                return;
                break;
            default:
                printf("Invalid choice\n");
                break;
        }

        printf("\n");
    } while (choice != 4);
}

void menu() {
    int select = 0, m = 0;
    pthread_t threads[16];
    pthread_create(&threads[11], NULL, QueueHandeler, NULL);
    while (1) {
        clearScreen();
        printf("Ram Available is: %d\n", ram);
        printf("1)  Calculator\n");
        printf("2)  Clock\n");
        printf("3)  Media Player\n");
        printf("4)  Notepad\n");
        printf("5)  Browser\n");
        printf("6)  File Explorer\n");
        printf("7)  Calender\n");
        printf("8)  Task Manager\n");
        printf("9)  Play Mines\n");
        printf("10) Play Mahjongg\n");
        printf("11) Play Rock Paper Scissors\n");
	printf("12) Refresh\n");
        printf("Press any other key to Shut Down system.\n");
        printf("Enter your selection: ");
        scanf("%d", &select);
        switch (select) {
        case 1:
            pthread_create(&threads[0], NULL, runCalculator, &m);
            sem_post(&lock);
            break;
        case 2:
            pthread_create(&threads[1], NULL, runClock, &m);
            sem_post(&lock);
            break;
        case 3:
            pthread_create(&threads[2], NULL, runVideo, &m);
            sem_post(&lock);
            break;
        case 9:
            pthread_create(&threads[3], NULL, runMines, &m);
            sem_post(&lock);
            break;
        case 5:
            pthread_create(&threads[4], NULL, runBrowser, &m);
            sem_post(&lock);
            break;
        case 6:
            pthread_create(&threads[5], NULL, runFileExplorer, &m);
            sem_post(&lock);
            break;
        case 7:
            pthread_create(&threads[6], NULL, runCal, &m);
            sem_post(&lock);
            break;
        case 8:
            pthread_create(&threads[7], NULL, runTM, &m);
            sem_post(&lock);
            break;
        case 4:
            pthread_create(&threads[8], NULL, runNote, &m);
            sem_post(&lock);
            break;
        case 10:
            pthread_create(&threads[9], NULL, runGames, &m);
            sem_post(&lock);
            break;
        case 11:
            pthread_create(&threads[10], NULL, runRockPaper, &m);
            sem_post(&lock);
            break;
	case 12:
	    break;
        default:
            clearScreen();
            printf("Signing out\n");
            sem_post(&lock);
            return;
            break;
        }
    }
}

int main() {
    sem_init(&lock, 0, 1);
    int choice;
    pthread_t end;

    Boot_loader();

    while (1) {
        printf("\n\n");
        printf("**************************\n");
        printf("1. Enter User Mode\n");
        printf("2. Enter Kernel Mode\n");
        printf("3. Exit\n");
        printf("**************************\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                switchToUserMode();
                printf("Entered User Mode\n");
                sleep(2);
                menu();
                break;
            case 2:
                switchToKernelMode();
                printf("Entered Kernel Mode\n");
                sleep(2);
                printKernelMenu();
                break;
            case 3:
             	printf("Shutting down\n");
            	pthread_create(&end, NULL, terminateAll, NULL);
            	pthread_join(end, NULL);
                printf("Exiting...\n");
                sem_destroy(&lock);
                exit(0);
            default:
                printf("Invalid choice\n");
        }
     }
    return 0;
}
