#!/bin/bash
gnome-mines
