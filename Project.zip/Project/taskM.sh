#!/bin/bash
gnome-system-monitor
