#!/bin/bash
gnome-calendar
echo "Press any key to terminate..."
read -n1 char
