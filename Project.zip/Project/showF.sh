#!/bin/bash
ls
echo "Press any key to terminate..."
read -n1 char
