#!/bin/bash
rhythmbox
