#!/bin/bash
firefox
