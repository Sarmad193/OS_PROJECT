#!/bin/bash
gnome-text-editor

