#!/bin/bash

function showdate(){
   printf '\033[;H' # Move the cursor to the top of the screen
   date             # Print the date (change with the format you need for the clock)
   sleep 1          # Sleep (pause) for 1 second
   showdate         # Call itself
}

clear               # Clear the screen
showdate            # Call the function which will display the clock
