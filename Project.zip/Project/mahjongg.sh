#!/bin/bash
gnome-mahjongg
